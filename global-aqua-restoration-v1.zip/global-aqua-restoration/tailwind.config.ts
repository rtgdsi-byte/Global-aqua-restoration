import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./app/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['Inter', 'ui-sans-serif', 'system-ui'] },
      colors: {
        deep: '#061826',
        aqua: '#13c8d2',
        ocean: '#0a4f70',
        mist: '#e8fbff'
      },
      boxShadow: { glow: '0 0 50px rgba(19,200,210,0.22)' }
    },
  },
  plugins: [],
}
export default config
