# Global Aqua Restoration Website

Professional Next.js website for Global Aqua Restoration.

## Deploy on Vercel

1. Upload these files to GitHub.
2. In Vercel, select **Add New Project**.
3. Import this GitHub repository.
4. Click **Deploy**.
5. Add the domain: `aswellglobalaquarestoration.com`.

## Notes

- Main logo: Global Aqua Restoration
- Footer/legal: Global Aqua Restoration, Inc.
- Languages: English, Spanish, Brazilian Portuguese
- Executive headshots are currently placeholders and can be replaced later.
