import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Global Aqua Restoration',
  description: 'International water restoration technology for lakes, rivers, wastewater, and environmental remediation.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
