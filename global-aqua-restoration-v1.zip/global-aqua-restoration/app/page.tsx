'use client'

import { useMemo, useState } from 'react'
import { Droplets, Globe2, ShieldCheck, Factory, Microscope, Leaf, Mail, MapPin, Users, FileText } from 'lucide-react'

type Lang = 'en' | 'es' | 'pt'

const copy = {
  en: {
    nav: ['Who We Are', 'Leadership', 'Technology', 'Solutions', 'Markets', 'Investors', 'Contact'],
    heroEyebrow: 'Clean Water • Sustainable Future',
    heroTitle: 'Restoring Water. Protecting Communities. Transforming the Future.',
    heroBody: 'Global Aqua Restoration is an international environmental water restoration company focused on large-scale solutions for lakes, rivers, wastewater systems, industrial sites, and strategic municipal projects.',
    cta1: 'Explore Technology',
    cta2: 'Contact Our Team',
    whoTitle: 'Who We Are',
    whoBody: 'We bring together business development, technical expertise, international relationships, and field-tested water restoration solutions to address some of the world’s most urgent freshwater and wastewater challenges.',
    mission: 'Our mission is to help governments, utilities, industrial operators, and communities restore water quality with practical, scalable, and environmentally responsible treatment programs.',
    leadership: 'Executive Leadership',
    techTitle: 'pH 104 Technology',
    techBody: 'Our proprietary low-pH water treatment technology is designed for environmentally responsible restoration, pathogen reduction, odor control, sludge reduction, and improved treatment efficiency at low concentrations.',
    solutionsTitle: 'Core Applications',
    validationTitle: 'Scientific Validation & Field Experience',
    marketsTitle: 'Strategic Markets',
    investorsTitle: 'Investment Opportunity',
    investorsBody: 'Global Aqua Restoration is positioned for expansion through pilot projects, government partnerships, municipal and industrial opportunities, university validation, and strategic commercialization in high-need water markets.',
    contactTitle: 'Start a Conversation',
    contactBody: 'For government, utility, university, commercial, or investor discussions, contact the Global Aqua Restoration leadership team.',
  },
  es: {
    nav: ['Quiénes Somos', 'Liderazgo', 'Tecnología', 'Soluciones', 'Mercados', 'Inversionistas', 'Contacto'],
    heroEyebrow: 'Agua Limpia • Futuro Sostenible',
    heroTitle: 'Restaurando el Agua. Protegiendo Comunidades. Transformando el Futuro.',
    heroBody: 'Global Aqua Restoration es una empresa internacional de restauración ambiental del agua enfocada en soluciones de gran escala para lagos, ríos, aguas residuales, sitios industriales y proyectos municipales estratégicos.',
    cta1: 'Explorar Tecnología',
    cta2: 'Contactar al Equipo',
    whoTitle: 'Quiénes Somos',
    whoBody: 'Integramos desarrollo de negocios, experiencia técnica, relaciones internacionales y soluciones probadas en campo para enfrentar desafíos críticos de agua dulce y aguas residuales.',
    mission: 'Nuestra misión es ayudar a gobiernos, empresas de servicios públicos, operadores industriales y comunidades a restaurar la calidad del agua con programas prácticos, escalables y ambientalmente responsables.',
    leadership: 'Liderazgo Ejecutivo',
    techTitle: 'Tecnología pH 104',
    techBody: 'Nuestra tecnología propietaria de bajo pH está diseñada para restauración ambiental, reducción de patógenos, control de olores, reducción de lodos y mayor eficiencia de tratamiento a bajas concentraciones.',
    solutionsTitle: 'Aplicaciones Principales',
    validationTitle: 'Validación Científica y Experiencia de Campo',
    marketsTitle: 'Mercados Estratégicos',
    investorsTitle: 'Oportunidad de Inversión',
    investorsBody: 'Global Aqua Restoration está posicionada para expandirse mediante proyectos piloto, alianzas gubernamentales, oportunidades municipales e industriales, validación universitaria y comercialización estratégica.',
    contactTitle: 'Iniciar una Conversación',
    contactBody: 'Para conversaciones gubernamentales, universitarias, comerciales, de servicios públicos o inversionistas, contacte al equipo directivo de Global Aqua Restoration.',
  },
  pt: {
    nav: ['Quem Somos', 'Liderança', 'Tecnologia', 'Soluções', 'Mercados', 'Investidores', 'Contato'],
    heroEyebrow: 'Água Limpa • Futuro Sustentável',
    heroTitle: 'Restaurando Águas. Protegendo Comunidades. Transformando o Futuro.',
    heroBody: 'A Global Aqua Restoration é uma empresa internacional de restauração ambiental da água focada em soluções de grande escala para lagos, rios, sistemas de esgoto, áreas industriais e projetos municipais estratégicos.',
    cta1: 'Explorar Tecnologia',
    cta2: 'Contato com a Equipe',
    whoTitle: 'Quem Somos',
    whoBody: 'Unimos desenvolvimento de negócios, expertise técnica, relacionamentos internacionais e soluções testadas em campo para enfrentar desafios urgentes de água doce e saneamento.',
    mission: 'Nossa missão é ajudar governos, concessionárias, operadores industriais e comunidades a restaurar a qualidade da água com programas práticos, escaláveis e ambientalmente responsáveis.',
    leadership: 'Liderança Executiva',
    techTitle: 'Tecnologia pH 104',
    techBody: 'Nossa tecnologia proprietária de baixo pH foi desenvolvida para restauração ambiental, redução de patógenos, controle de odores, redução de lodo e maior eficiência de tratamento em baixas concentrações.',
    solutionsTitle: 'Aplicações Principais',
    validationTitle: 'Validação Científica e Experiência de Campo',
    marketsTitle: 'Mercados Estratégicos',
    investorsTitle: 'Oportunidade de Investimento',
    investorsBody: 'A Global Aqua Restoration está posicionada para expansão por meio de projetos piloto, parcerias governamentais, oportunidades municipais e industriais, validação universitária e comercialização estratégica.',
    contactTitle: 'Iniciar uma Conversa',
    contactBody: 'Para discussões com governos, concessionárias, universidades, empresas ou investidores, entre em contato com a liderança da Global Aqua Restoration.',
  }
}

const leaders = [
  ['Ross Trevino', 'Chief Executive Officer & Chairman'],
  ['Roberto Barbuci', 'Senior Business Advisor'],
  ['Luis Machado', 'Brazilian General Manager'],
  ['Edigimar Antonio Maximiliano Jr.', 'Investor Relations'],
]

const solutions = [
  ['Lake Restoration', 'Improve water clarity, reduce odor, and support healthier aquatic ecosystems.'],
  ['Wastewater Treatment', 'Support municipal and industrial treatment programs with scalable solutions.'],
  ['Sludge Reduction', 'Improve treatment efficiency and reduce operational burden.'],
  ['Water Purification', 'Address contaminants, pathogens, and environmental water-quality challenges.'],
  ['Recreational Water', 'Support safer, cleaner public and private recreational water environments.'],
  ['Industrial Applications', 'Customized programs for high-need industrial water restoration challenges.'],
]

const markets = ['United States', 'Brazil', 'Canada', 'Caribbean', 'Mexico', 'Panama', 'Central America', 'South America', 'Vietnam', 'Malaysia']

export default function Home() {
  const [lang, setLang] = useState<Lang>('en')
  const t = copy[lang]

  const stats = useMemo(() => [
    ['99.99%', 'Pathogen reduction results'],
    ['pH 104', 'Proprietary technology platform'],
    ['10+', 'Strategic global markets'],
    ['4', 'Executive leadership functions'],
  ], [])

  return (
    <main className="min-h-screen overflow-hidden bg-deep text-white">
      <nav className="fixed left-0 right-0 top-0 z-50 border-b border-white/10 bg-deep/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
          <a href="#top" className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-2xl bg-aqua text-deep"><Droplets size={22}/></span>
            <span className="text-sm font-semibold tracking-[0.22em] md:text-base">GLOBAL AQUA RESTORATION</span>
          </a>
          <div className="hidden items-center gap-6 text-sm text-white/75 lg:flex">
            {t.nav.map((item, i) => <a key={item} href={`#${['who','leadership','technology','solutions','markets','investors','contact'][i]}`} className="hover:text-aqua">{item}</a>)}
          </div>
          <div className="flex gap-2">
            {(['en','es','pt'] as Lang[]).map(code => (
              <button key={code} onClick={() => setLang(code)} className={`rounded-full px-3 py-1 text-xs font-semibold ${lang === code ? 'bg-aqua text-deep' : 'bg-white/10 text-white/70'}`}>{code.toUpperCase()}</button>
            ))}
          </div>
        </div>
      </nav>

      <section id="top" className="relative flex min-h-screen items-center pt-24">
        <div className="absolute inset-0 gradient-grid opacity-50" />
        <div className="water-orb absolute right-[-18rem] top-10 h-[42rem] w-[42rem] rounded-full" />
        <div className="water-orb absolute bottom-[-20rem] left-[-18rem] h-[38rem] w-[38rem] rounded-full opacity-70" />
        <div className="relative mx-auto grid max-w-7xl gap-12 px-5 py-20 lg:grid-cols-[1.2fr_.8fr] lg:items-center">
          <div>
            <div className="badge inline-flex items-center gap-2"><Leaf size={16}/>{t.heroEyebrow}</div>
            <h1 className="mt-8 max-w-5xl text-5xl font-semibold leading-tight tracking-tight md:text-7xl">{t.heroTitle}</h1>
            <p className="mt-7 max-w-3xl text-lg leading-8 text-white/75 md:text-xl">{t.heroBody}</p>
            <div className="mt-10 flex flex-col gap-4 sm:flex-row">
              <a href="#technology" className="rounded-full bg-aqua px-7 py-4 text-center font-semibold text-deep shadow-glow">{t.cta1}</a>
              <a href="#contact" className="rounded-full border border-white/20 px-7 py-4 text-center font-semibold text-white hover:border-aqua">{t.cta2}</a>
            </div>
          </div>
          <div className="card">
            <div className="aspect-square rounded-[2rem] border border-aqua/20 bg-[radial-gradient(circle_at_center,rgba(19,200,210,.35),rgba(255,255,255,.05)_45%,rgba(255,255,255,.02)_70%)] p-7">
              <div className="flex h-full flex-col justify-between rounded-[1.5rem] border border-white/10 p-7">
                <Globe2 className="text-aqua" size={42}/>
                <div>
                  <p className="text-sm uppercase tracking-[.35em] text-aqua">International Water Restoration</p>
                  <h2 className="mt-5 text-3xl font-semibold">Brazil • Americas • Southeast Asia</h2>
                  <p className="mt-4 text-white/65">Scalable environmental technology for public and private water challenges.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="who" className="mx-auto max-w-7xl px-5 py-24">
        <div className="grid gap-10 lg:grid-cols-[.8fr_1.2fr]">
          <div><span className="badge">Corporate Overview</span><h2 className="section-title mt-6">{t.whoTitle}</h2></div>
          <div><p className="section-copy">{t.whoBody}</p><p className="section-copy">{t.mission}</p></div>
        </div>
        <div className="mt-12 grid gap-4 md:grid-cols-4">{stats.map(([a,b]) => <div key={a} className="card"><p className="text-3xl font-semibold text-aqua">{a}</p><p className="mt-2 text-sm text-white/65">{b}</p></div>)}</div>
      </section>

      <section id="leadership" className="bg-white/[0.035] py-24">
        <div className="mx-auto max-w-7xl px-5">
          <span className="badge"><Users size={16}/> Leadership</span>
          <h2 className="section-title mt-6">{t.leadership}</h2>
          <p className="section-copy">Experienced business, advisory, country management, and investor relations leadership for international expansion.</p>
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {leaders.map(([name, role]) => <div key={name} className="card text-center">
              <div className="mx-auto grid h-28 w-28 place-items-center rounded-full border border-aqua/30 bg-aqua/10 text-3xl font-semibold text-aqua">{name.split(' ').map(n=>n[0]).slice(0,2).join('')}</div>
              <h3 className="mt-6 text-xl font-semibold">{name}</h3><p className="mt-2 text-sm text-aqua">{role}</p>
              <p className="mt-5 text-sm text-white/55">Executive photo placeholder. Replace with professional headshot later.</p>
            </div>)}
          </div>
        </div>
      </section>

      <section id="technology" className="mx-auto max-w-7xl px-5 py-24">
        <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div><span className="badge"><Microscope size={16}/> Technology Platform</span><h2 className="section-title mt-6">{t.techTitle}</h2><p className="section-copy">{t.techBody}</p></div>
          <div className="grid gap-5">
            {[['Patented low-pH Safe Acid technology', ShieldCheck], ['Algicide, bactericide, fungicide, virucide use cases', Microscope], ['Effective at very low concentrations', Droplets], ['Designed for responsible environmental treatment', Leaf]].map(([txt, Icon]: any) => <div key={txt} className="card flex items-center gap-4"><Icon className="text-aqua"/><span>{txt}</span></div>)}
          </div>
        </div>
      </section>

      <section id="solutions" className="bg-white/[0.035] py-24">
        <div className="mx-auto max-w-7xl px-5"><span className="badge"><Factory size={16}/> Solutions</span><h2 className="section-title mt-6">{t.solutionsTitle}</h2>
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">{solutions.map(([title, body]) => <div key={title} className="card"><h3 className="text-xl font-semibold text-aqua">{title}</h3><p className="mt-4 text-white/65">{body}</p></div>)}</div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-24">
        <span className="badge"><FileText size={16}/> Validation</span><h2 className="section-title mt-6">{t.validationTitle}</h2>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {['E. coli and Streptococcus testing', 'Helminth egg treatment studies', 'Lake Texcoco and Huu Tiep Lake case study experience'].map(x => <div className="card" key={x}><p className="text-lg font-semibold">{x}</p><p className="mt-3 text-white/60">Supporting technical documents, photos, certifications, and laboratory reports can be added as they become available.</p></div>)}
        </div>
      </section>

      <section id="markets" className="bg-white/[0.035] py-24">
        <div className="mx-auto max-w-7xl px-5"><span className="badge"><MapPin size={16}/> Global Presence</span><h2 className="section-title mt-6">{t.marketsTitle}</h2><p className="section-copy">Focused international expansion across the Americas and Southeast Asia, with Brazil as a major strategic market.</p>
          <div className="mt-10 flex flex-wrap gap-3">{markets.map(m => <span key={m} className="rounded-full border border-white/15 bg-white/5 px-5 py-3 text-white/80">{m}</span>)}</div>
        </div>
      </section>

      <section id="investors" className="mx-auto max-w-7xl px-5 py-24">
        <div className="card md:p-10"><span className="badge">Investor Relations</span><h2 className="section-title mt-6">{t.investorsTitle}</h2><p className="section-copy">{t.investorsBody}</p></div>
      </section>

      <section id="contact" className="bg-white/[0.035] py-24">
        <div className="mx-auto grid max-w-7xl gap-10 px-5 lg:grid-cols-2">
          <div><span className="badge"><Mail size={16}/> Contact</span><h2 className="section-title mt-6">{t.contactTitle}</h2><p className="section-copy">{t.contactBody}</p></div>
          <form className="card grid gap-4" action="mailto:info@aswellglobalaquarestoration.com" method="post" encType="text/plain">
            <input className="rounded-2xl border border-white/10 bg-white/10 p-4 outline-none focus:border-aqua" placeholder="Name" />
            <input className="rounded-2xl border border-white/10 bg-white/10 p-4 outline-none focus:border-aqua" placeholder="Email" />
            <input className="rounded-2xl border border-white/10 bg-white/10 p-4 outline-none focus:border-aqua" placeholder="Organization" />
            <textarea className="min-h-32 rounded-2xl border border-white/10 bg-white/10 p-4 outline-none focus:border-aqua" placeholder="Message" />
            <button className="rounded-full bg-aqua px-7 py-4 font-semibold text-deep">Send Inquiry</button>
          </form>
        </div>
      </section>

      <footer className="border-t border-white/10 px-5 py-10 text-center text-sm text-white/55">
        <p className="font-semibold text-white">Global Aqua Restoration</p>
        <p className="mt-2">Global Aqua Restoration, Inc. • Clean Water • Sustainable Future</p>
        <p className="mt-2">aswellglobalaquarestoration.com</p>
      </footer>
    </main>
  )
}
